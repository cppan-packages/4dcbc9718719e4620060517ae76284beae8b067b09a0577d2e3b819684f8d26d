/*
 * Copyright (C) 2010 Emweb bvba, Kessel-Lo, Belgium.
 *
 * See the LICENSE file for terms of use.
 */

#include "Wt/Dbo/SqlConnectionPool.h"

namespace Wt {
  namespace Dbo {

SqlConnectionPool::~SqlConnectionPool()
{ }

  }
}
